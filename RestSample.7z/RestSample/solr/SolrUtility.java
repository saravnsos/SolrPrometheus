package com.solr;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.impl.XMLResponseParser;
import org.apache.solr.client.solrj.io.stream.CloudSolrStream;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.springframework.stereotype.Component;

import com.accounts.AccountDetails;
import com.accounts.AddAccountRequest;
import com.accounts.AddAccountResponse;

@Component
public class SolrUtility {

	public AddAccountResponse readDocument(AccountSearchBean searchBean)
	{
		AddAccountResponse accountResponse=null;
		
		
		String url = "http://ats-solr.org:30305/solr/cvmcollection/";
		//String url = "http://ats-solr.org:30305/zk/";

		HttpSolrClient solr = new HttpSolrClient.Builder(url).build();
		solr.setParser(new XMLResponseParser());
		SolrDocument list=null;
		try {
			
			SolrQuery q=new SolrQuery();
			StringBuffer buf=new StringBuffer();
			if(null!=searchBean.getId())
			{
				buf.append("id:").append(searchBean.getId());
			}
			if(null!=searchBean.getTypeCode())
			{
				buf.append(" AND TypeCode:").append(searchBean.getTypeCode());
			}
			if(null!=searchBean.getCity())
			{
				buf.append(" AND City:").append(searchBean.getCity());
			}
			if(null!=searchBean.getState())
			{
				buf.append(" AND State:").append(searchBean.getState());
			}
			q.setQuery(buf.toString());
			
			QueryResponse resp=null;
			resp=solr.query(q);
			SolrDocumentList docList=null;
			docList=resp.getResults();
			for (SolrDocument solrDocument : docList) {
				accountResponse=new AddAccountResponse();
				
				Collection<String> fieldNames=new ArrayList<String>();
				
				fieldNames=solrDocument.getFieldNames();
				AccountDetails accountDetails=new AccountDetails();
				
				for (String string : fieldNames) {
					
					if(string.equalsIgnoreCase("id"))
					{
						Integer id=new Integer((String)solrDocument.getFieldValue(string));
						accountDetails.setObjId(id.intValue());
					}else if(string.equalsIgnoreCase("ExternalId"))
					{
						accountDetails.setExternalId((Long)solrDocument.getFieldValue(string)+"");
					}else if(string.equalsIgnoreCase("TypeCode"))
					{
						accountDetails.setTypeCode((String)solrDocument.getFieldValue(string));
					}else if(string.equalsIgnoreCase("City"))
					{
						accountDetails.setCity((String)solrDocument.getFieldValue(string));
					}else if(string.equalsIgnoreCase("State"))
					{
						accountDetails.setState((String)solrDocument.getFieldValue(string));
					}else if(string.equalsIgnoreCase("AddCountryCode"))
					{
						accountDetails.setAddcountryCode((String)solrDocument.getFieldValue(string));
					}
					System.out.println("The field Name:"+string);
					System.out.println("The field value:"+solrDocument.getFieldValue(string));
				}
				accountResponse.setAccountDetails(accountDetails);
				
			}
			/*
			 * list=solr.getById(id); if(null!=list) { Collection<String> fieldNames=new
			 * ArrayList<String>();
			 * 
			 * fieldNames=list.getFieldNames(); for (String string : fieldNames) {
			 * System.out.println("The field Name:"+string);
			 * System.out.println("The field value:"+list.getFieldValue(string)); } }
			 */
		} catch (SolrServerException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accountResponse;
	}
	
	public void insertDocument(AddAccountRequest request) {
		try {
			
			/*
			 * String zkHostString = "http://ats-solr.org:30305/zk/"; List<String> list=new
			 * ArrayList<String>(); list.add(zkHostString); CloudSolrStream zk=new
			 * CloudSolrStream(zkHostString, "cvmcollection", null);
			 * System.out.println("zk"+zk);
			 */
			   // CloudSolrClient	solr = new CloudSolrClient.Builder(list).build();

			
			System.out.println("Inside SolrUtility()");
			//String url = prop.readProperty("SOLR_URL");
			String url = "http://ats-solr.org:30305/solr/cvmcollection/";
			//String url = "http://ats-solr.org:30305/zk/";

			HttpSolrClient solr = new HttpSolrClient.Builder(url).build();
			solr.setParser(new XMLResponseParser());
			SolrInputDocument document = new SolrInputDocument(
					);

			if (request != null) {

				document.addField("id", request.getObjId());
				document.addField("ExternalId", request.getExternalId());
				document.addField("TypeCode", request.getTypeCode());
				document.addField("ExpirationTimeStamp", request.getExpirationTimestamp());
				document.addField("CustomerView", request.getCustomerView());
				document.addField("CustomerVIewModel", request.getCustomerViewModelValue());
				document.addField("CompanyTypeCode", request.getCompanyTypeCode());
				document.addField("CompanyDescription", request.getCompanyDescription());
				document.addField("PhoneTypeCode", request.getPhoneTypeCode());
				document.addField("PhoneCountryCode", request.getPhcountryCode());
				document.addField("AreaCode", request.getAreaCode());
				document.addField("PhoneNumber", request.getPhoneNumber());
				document.addField("Extension", request.getExtension());
				document.addField("AddressTypeCode", request.getAddressTypeCode());
				document.addField("StreetLine1", request.getStreetLine1());
				document.addField("StreetLine2", request.getStreetLine2());
				document.addField("StreetLine3", request.getStreetLine3());
				document.addField("City", request.getCity());
				document.addField("State", request.getState());
				document.addField("PostalCode", request.getPostalCode());
				document.addField("AddCountryCode", request.getAddcountryCode());

			}
			solr.add(document);

			solr.commit();

		} catch (SolrServerException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		} catch (IOException e) {

			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}
}
