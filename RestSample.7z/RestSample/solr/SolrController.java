package com.solr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.accounts.AddAccountRequest;
import com.accounts.AddAccountResponse;

@RestController
public class SolrController {

	@Autowired
	SolrUtility solrUtility;
	
	@PostMapping(path = "/readData",consumes = {"application/json"})
	
	public ResponseEntity<AddAccountResponse> readSolr(@RequestBody AccountSearchBean searchBean)
	{
		System.out.println("Printing Data:");
		AddAccountResponse accountResponse=null;
		accountResponse=solrUtility.readDocument(searchBean);
		return ResponseEntity.ok(accountResponse);	
	}
	
	@PostMapping(path = "/writeData",consumes = {"application/json"})
	public ResponseEntity<String> writeSolr(@RequestBody AddAccountRequest addRequest)
	{
		System.out.println("Object Id:"+addRequest.getObjId());
		System.out.println("External Id:"+addRequest.getExternalId());
		solrUtility.insertDocument(addRequest);
	
	return ResponseEntity.ok("The object is savedin solr");	
	}
}
