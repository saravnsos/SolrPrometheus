package com.solr;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.apache.solr.client.solrj.impl.XMLResponseParser;
import org.apache.solr.client.solrj.io.stream.CloudSolrStream;

import com.accounts.AddAccountRequest;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestSolr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ObjectMapper obj=new ObjectMapper();
		TestSolr tSolr=new TestSolr();
		AddAccountRequest req=tSolr.getAccountRequest();
		try {
			/*
			 * String zkHostString = "http://ats-solr.org:30305/zk/"; List<String> list=new
			 * ArrayList<String>(); list.add(zkHostString); //CloudSolrStream zk=new
			 * CloudSolrStream(zkHostString, "cvmcollection", new HashMap<String,
			 * String>()); CloudSolrClient solr = new CloudSolrClient.Builder(list).build();
			 * solr.setParser(new SolrXMLResponseParser()); solr.connect();
			 */
			AccountSearchBean searchBean=new AccountSearchBean();
			searchBean.setId("202");
			searchBean.setTypeCode("HUBREF");
			searchBean.setCity("NEW YORK");
			//obj.writeValue(new File("F:\\docker\\AccountSearchBean.txt"), searchBean);
			
		//System.out.println("zk"+solr);
			obj.writeValue(new File("F:\\docker\\Addaccount.txt"), req);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public AddAccountRequest getAccountRequest()
	{
		AddAccountRequest req=new AddAccountRequest();
		req.setObjId(Integer.valueOf(4002));
		req.setExternalId("456789");
		req.setTypeCode("HUBREF");
		req.setCustomerView("CORE");
		req.setCompanyTypeCode("PRI");
		req.setCompanyDescription("Grissom Afb Fire Dept");
		req.setExpirationTimestamp("2016-12-21 15.30.20");
		req.setCustomerViewModelValue("CI");
		req.setAreaCode("TOO");
		req.setStreetLine1("WEST AVE");
		req.setStreetLine2("100 WEST");
		req.setStreetLine3("200 WEST");
		req.setCity("NEW YORK");
		req.setState("FL");
		req.setPostalCode("US");
		req.setEffectiveTimestamp("2016-12-21 15.30.20");
		req.setPhoneTypeCode("BILL");
		req.setPhoneNumber("100325689");
		req.setPhcountryCode("BILL");
		req.setPostalCode("69026344");
		
		return req;	
	}

}
