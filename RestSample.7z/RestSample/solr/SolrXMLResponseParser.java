package com.solr;

import org.apache.solr.client.solrj.impl.XMLResponseParser;

public class SolrXMLResponseParser extends XMLResponseParser {
	
	@Override
	public String getContentType() {
		// TODO Auto-generated method stub
		return "text/xml; charset=UTF-8";
	}

}
